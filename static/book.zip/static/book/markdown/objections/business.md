# Objection Handlers

#### Objection: I'm already invested in protocol projects that are targetting those emerging markets

Handler: We're building physical hardware that will lead to ease of adoption for all protocols including the ones you have already done research on

#### Objection: I plan on being part of X, which his similar to what you're doing 

Handler: I've created a novel and original method of managing ones cap table, turned it into a product, that will create greater ROI due to precedence and my extensive experience with go to market launches

#### Objection: I still don't understand what you're building or what you're doing? 

Handler: Some have said we are in the greatest financial upside opportunity in this century. And the analogous base case study (of how expensive hiring has been due to inflation) has already been validated. Long story short we have the number one way to hire a software engineer, at the most economical price point. 

#### Objection: I don't see the point in doing this extra paper work

Handler: There will be future compliance requirements to be obtained as the product evolves. Those will each have fees in the thousands if not millions of dollars. Imagine being able to cut each of those fees by half

#### Objection: I'd rather keep things simple

Handler: I can speak from experience that building and retaining an all star team requires much more effort than 1 or 2 high performance individuals to handle. 

#### Objection: Why is there a lull in activity in the middle

Handler: I made the decision to make our cloud infrastructure more resilient. Given the trend of some of the biggest cloud providers: Microsoft, Amazon, Google - all making investments in cybersecurity for good reason, we did the same. 

#### Objection: How did you know if that was worth the cost?

Handler: We looked at the data. In a recent report by Gartner `[1]`, analysts estimated that global cloud spending worldwide is on track to increase 23% year over year `[2]`. Global cloud revenue will total $474 billion this year, up from $408 billion in 2021. 


## References

1. https://www.techrepublic.com/article/gartner-top-security-and-risk-management-trends-for-2021/
2. https://www.cnbc.com/2022/03/29/google-microsoft-ramp-up-cloud-security-as-cyberattacks-increase.html