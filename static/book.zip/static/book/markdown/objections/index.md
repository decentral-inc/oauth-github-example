# Organization

Objection handlers will be organized in files by category. This allows for 