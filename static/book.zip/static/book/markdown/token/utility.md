# Utility 

## rational decisions

To make smart financial choices let us define an agent a as an object with a set of preferences, represented in property fields 

**Utility**: defined in literature as "the quality of being useful" 

  
**Utility of money**: define in literature as "a value almost exactly proportional to the logarithm of the amount of money"

**Utility function**: defined in literature as "a mapping between games of chance to real quantitative outcomes"

**Utility theory**: defined in literature as "a way to represent state with reason and preferences", other common definitions are "every state has a degree of usefulness, or utility, to an agent and that the agent will prefer states with higher utility  "

  
We represent our set of network units as a graph representation. Further we define the topology of the network as a set of nodes and pointers. We will apply a five-step state transition diagram for each individual unit in the network. In this scenario, we have a socially beneficial outcome. 

The closest motto to this would be a stag hunt. A stack on is defined where a group of hunters must wait patiently for a stag to appear in a hunting area. If all the hunters follow the protocol and wait, a stag will show up and the hunters can work together to capture it. In this scenario, if rabbits show up, and one of the hunters takes a selfish action and makes an attempt to capture the rabbit, the stag will not show up and the rest of the hunters go hungry. If we have n hunters. The calories gained from digesting a rabbit would be significantly less than `NumCalories(stag) * 1/n`.  

In this scenario the rational hunters shows their best action `a*` to maximize expected utility. This model can be adapted to many common in person scenarios. For example hosting a business conference, collaborating on contracts for improving the cash flow of a business, pooling together resources for an investment 

### Equation

**EU**: Exepcted Utility of an event.  

```
a* <= argmaxEU(a|e)
```

