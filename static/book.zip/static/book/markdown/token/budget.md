# Budget

### On Premise Requirements


|Requirement |Timeline |Notes |
|-|-|-| 
|Must have 2 servers running OAuth2 | | |
|Must implement RFC6750 and RFC7636 so that mobile auth can be done correctly and safely in production | | |
|Must be an entry for a unique automatically generated ID  | |Specification shall allow for user models to be either Postgres SQL or JSON or BSON|
|Codebase shall in future iterations support a user who logged in/signed up with their extension will have the ability to switch to an email/password type of account  | | and gives them an option to remove the link to their OAuth2 provider|


### Round 1A Convertible Note


### Round 1B Convertible Note

### Priced Round 2 Series A 

