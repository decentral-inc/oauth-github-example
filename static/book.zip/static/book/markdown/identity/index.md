# How to recover identity documents

This document to serve as defense manual against cybersecurity attacks

1. Contact Virginia government website for vital records 
2. If there are any delays in email communication with Virginia vital records office contact toll free 877-572-6333
3. Pay them with CC over phone _Another condition for using this system is that payment must be made by credit card._
4. Choose regular mail USPS as shipping option [1]



### Step 3 out of 3

Obtain photocopy (scanner from Library) and include in Envelope **at least 1** of the following Primary Identity Documents

* Photo Driver's License issued by US State territory or jurisdiction (must be unexpired)
* US Passport or passport card
* Unexpired Foreign Passport with Visa, I-94 or I-94W
* Asylum - A copy of the first and last page of application for Asylum
* Employment Authorization Document (unexpired form I-766)
* Refugee Travel Document (unexpired form I-571)

Obtain photocopy (scanner from Library) and include in Envelope **at least 2** of the following Secondary Identity documents 

* Health insurance card
* US Passport or passport card 
* Unexpired weapon or gun permit issued by federal, state or municipal government


#### References

1. https://www.vdh.virginia.gov/vital-records/express-delivery-through-the-vitalchek-network/

> The Virginia Health Department (VDH) has contracted the VitalChek Network to help people get a certified copy of a birth, death, marriage, or divorce certificates within 2 to 5 days! Once VDH has received the VitalChek information, VDH staff members will search, print, and send a certified copy of your request. Please note that you will be required to sign for the UPS package.
