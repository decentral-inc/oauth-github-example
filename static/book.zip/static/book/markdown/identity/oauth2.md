# OAuth2

### Required Dependencies

A network that can be exposed to the public. 

Search term `Double NAT` with router. 

For example, using `curl`:

```zsh
curl http://192.168.0.208:4000/oauth/token \
	-d "grant_type=password" \
	-d "username=pedroetb" \
	-d "password=password" \
	-H "Authorization: Basic YXBwbGljYXRpb246c2VjcmV0" \
	-H "Content-Type: application/x-www-form-urlencoded"
```

Expect a result like

```
{"accessToken":"5210d1c13959b40b5af4181c2d4c49b31c9e8591","accessTokenExpiresAt"
:"2022-03-13T06:18:40.721Z","refreshToken":"68dd30195e24bf7b1c74ce776b5c400bc5af
f0a1","refreshTokenExpiresAt":"2022-03-27T05:18:40.721Z","client":{"id":"applica
tion"},"user":{"username":"pedroetb"}}
```

So take a look at [client](./client.md). In the section titled **Using the token**

```js
function authenticateRequest(req, res, next) {
  var request = new Request(req);
  var response = new Response(res);
  return app.oauth.authenticate(request, response)
    .then(function(token) {
      next();
    }).catch(function(err) {
      res.status(err.code || 500).json(err);
    });
}
```

The logic `authenticateRequest()` is middleware for the route for `/`. Since we supplied the correct header.

```zsh
curl http://192.168.0.208:4000 \
> -H "Authorization: Bearer 5210d1c13959b40b5af4181c2d4c49b31c9e8591"

Congratulations, you are in a secret area!
```

We get the success message. Let's dive deeper in the library

```js
/**
 * Constructor.
 */

function Request(options) {
  options = options || {};
  if (!options.headers) {
    throw new InvalidArgumentError('Missing parameter: `headers`');
  }
  if (!options.method) {
    throw new InvalidArgumentError('Missing parameter: `method`');
  }
  if (!options.query) {
    throw new InvalidArgumentError('Missing parameter: `query`');
  }
  this.body = options.body || {};
  this.headers = {};
  this.method = options.method;
  this.query = options.query;
  // Store the headers in lower case.
  for (var field in options.headers) {
    if (Object.prototype.hasOwnProperty.call(options.headers, field)) {
      this.headers[field.toLowerCase()] = options.headers[field];
    }
  }
  // Store additional properties of the request object passed in
  for (var property in options) {
    if (Object.prototype.hasOwnProperty.call(options, property) && !this[property]) {
      this[property] = options[property];
    }
  }
}
```

This is what the request constructor is. Remember JS `call` simply polymerizes 2 closures together.
If `call` has multiple arguments, it sets variable `options` to be what is in the `this` context. 
The first arg in the function being called (whether or not it is a constructor) would be `property`


After that it returns `app.oauth.authenticate()` which is defined below. 

> Note: `assign()` method comes from the lodash libary.

```js
/**
 * Authenticate a token.
 */
OAuth2Server.prototype.authenticate = function(request, response, options, callback) {
  if (typeof options === 'string') {
    options = {scope: options};
  }

  options = _.assign({
    addAcceptedScopesHeader: true,
    addAuthorizedScopesHeader: true,
    allowBearerTokensInQueryString: false
  }, this.options, options);

  return new AuthenticateHandler(options)
    .handle(request, response)
    .nodeify(callback);
};
```

After doing a few basic checks it goes into `handle`

```js
AuthorizationCodeGrantType.prototype.handle = function(request, client) {
  if (!request) {
    throw new InvalidArgumentError('Missing parameter: `request`');
  }
  if (!client) {
    throw new InvalidArgumentError('Missing parameter: `client`');
  }
  return Promise.bind(this)
    .then(function() {
      return this.getAuthorizationCode(request, client);
    })
    .tap(function(code) {
      return this.validateRedirectUri(request, code);
    })
    .tap(function(code) {
      return this.revokeAuthorizationCode(code);
    })
    .then(function(code) {
      return this.saveToken(code.user, client, code.authorizationCode, code.scope);
    });
};
```

What does `Promise.tap()` do you ask? 

> `Promise.tap()` allows one to essentially call a . `then()` without altering the value being passed through the chain