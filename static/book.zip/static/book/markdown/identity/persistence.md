# Installing Persistence on Windows 10

### Starting State

* Created non-admin user on Windows 10 OS
* Node JS installed
* Yarn installed with `.msi` file


#### Step 1

1. Go to control panel and follow [this guide](https://docs.microsoft.com/en-us/sql/reporting-services/report-server/configure-a-firewall-for-report-server-access?view=sql-server-ver15)
2. Forward ports XX00-XX99 
2. Test this by running a node application on port XX00 and verify connecting locally works



### Reference Material

#### Proxy Server

Analogy of proxy server. Consider the intent to communicate to a cybersecurity professional but without people in your industry to know you are talking to her, and you also don't want the cybersecurity professional to have full awareness on why you're talking to her. 

So you request your VC to forward a letter to them. The VC passes on the message and will let you know what the cybersecurity professional says, when the VC hears back from the professional he or she will forward what the professional has said. 