### Executive Assistant

|Salary | 
|-|
|$64,817 - $111,978 per annum|

#### Job Description

####  Summary

We are a team of high performance individuals. Artists. The starting lineup. Always hunting for the next best product, strategy, execution. Whether you’re with us in our offices in Santa Clara and San Francisco, or even remotely, a job at Decentral will be demanding. Yet we reward those that deliver results. Those that can think bottom up, from a first principles standpoint. And we wouldn’t ask for anything else. 

At Decentral, we don’t just build software. We innovate where we are recognized at the top of adjacent industries. Join the team that manifests the standards of excellence, and that does whatever it takes to realize that value. We want your unique experience and strengths to guide us to a better tomorrow. 

Does a resourceful, dynamic and withstanding environment activate your reticular activation system? Do you like to venture into that part of the world where you can’t “Google your answers” to solve your problems anymore? It happens when your abilities cross the threshold from exceptional into elite. If you know what that feels like, you’ll be a great fit for our team!

![](https://s3-us-west-2.amazonaws.com/fireteam-alpha/https-decentral-solutions-cdn/DSC00762_preview.jpeg)

A couple of requirements so that you’ll be ready to hit the ground running. 

- At least 3 years of experience working with C suite executives in a professional setting, where the C suite was part of an organization of over 50 employees
- Tried and tested ability multitasking multiple deadlines across several departments
- Have a battle sense where you understand how priorities may have shifted by being able to put yourself in the shoes of a C suite executive
- Cool and collected during high pressure situations
- Experience with speaking about and handling highly sensitive documents, such as company intellectual property and consumer credit data


#### Your day to day functions

You'll work directly with the executive team planning day to day functions. Strategizing different types of fundraising so that the company can hit important milestones. We're building a tight knit team that are comfortable in almost any situation. We all have a track record of past success. We all hold each other accountable to be our best. 


* Planning and monitoring the day to day running of business to ensure progress across all departments
* Supervising staff from different departments and provide constructive feedback. Provide direct 1 on 1 coaching sessions so each employee is able to reach their defined annual outcomes
* Submit grant applications, once a quarter organize startup pitch competitions, perform analysis on pitch decks and whitepapers from our partner and or customer firms
