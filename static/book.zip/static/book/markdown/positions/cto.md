# Chief Technology Officer


|Salary | 
|-|
|$92,967 - $119,987 per annum|

#### Job Description

####  Summary


We are a team of high performance individuals. Artists. The starting lineup. Always hunting for the next best product, strategy, execution. Whether you’re with us in our offices in Santa Clara and San Francisco, or even remotely, a job at Decentral will be demanding. Yet we reward those that deliver results. Those that can think bottom up, from a first principles standpoint. And we wouldn’t ask for anything else. 

At Decentral, we don’t just build software. We innovate where we are recognized at the top of adjacent industries. Join the team that manifests the standards of excellence, and that does whatever it takes to realize that value. We want your unique experience and strengths to guide us to a better tomorrow. 

Does a resourceful, dynamic and withstanding environment activate your reticular activation system? Do you like to venture into that part of the world where you can’t “Google your answers” to solve your problems anymore? It happens when your abilities cross the threshold from exceptional into elite. If you know what that feels like, you’ll be a great fit for our team!

![](https://s3-us-west-2.amazonaws.com/fireteam-alpha/https-decentral-solutions-cdn/DSC00762_preview.jpeg)

The candidate will be on our infrastructure team, developing systems for our backend and core platform that powers web and mobile applications. We are a fast growing company that is creating infrastructure at a rapid pace. We're looking for a talented individual who wants to work at the forefront of blockchain and AI. 

The CTO will participate in discussions with engineers, draft requirements, review them with the core team both technical and non-technical. They will demonstrate effective and comprehensive communication for technology requirements to respective teams. Create reporting and communication standards that span our team as we grow. Create the structure so that new testers, desginers, product owners have the systems in place for success. 

This will include decision making on how projects and structured. Experience with P&L is strongly preferred, and an ideal candidate will be responsible for the successful launch of our platform and products. 


## Requirements

* At least 5 years of professional software development experience
* At least 2 years of Rust and or Java development experience
* Set developer best practices for all technology related team members
  * An environment that enables consistent checkins of clean and maintainable code
  * A high performance culture so that new engineers can contribute to the production code base on day one
* Breadth of experience launching multiple types of applications and infrastructure to production
* Extensive experience with cryptographic primitives which includes deep understanding on low level networking
  * For example how TLS, HTTPS, SSL work together
* At least 3 years of experience deploying Rust or C++ code to production on cloud platforms 



Being able to communicate so that firm policy is effectively applied, and team members are educated on that new policy in a way that maximizes retention of understanding. 

Creating a culture such that employees are motivated and understand why they might need to go out of the way in order to achieve firm objectives

> This can be applied to building a new set of habits that reflect more proficient cybersecurity skills 
> Creating a culture where each individuals understand company growth will be a by-product of their own personal growth
> As a business leader, you will successfully enforce policy for various operational process requirements
> When there is a disagreement, be able to handle and resolve the situation - even if it uncomfortable to bring up in the moment

## Roles and responsibilities




* Provide P&L forecasts for the engineering budget
  - Launch services at scale using Rust, Nginx, Node JS, Kubernetes
  - Create an effective team of full stack devs building on frameworks such as Angular/Vue/React
* Take ownership of software architecture so that codebase remains flexible for the long term
  - Manage PKI infrastructure including deploy keys, developer SSH and PGP keys
  - Automating deployments of containers connected to a configurable set of blockchain nodes
* Host sets of Bitcoin/Ethereum/Polkadot nodes in a secure environment 
* Postgres or other SQL experience strongly preferred
