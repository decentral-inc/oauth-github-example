### Network Engineer

#### Job Description

|Salary | 
|-|
|$83,342 - $139,241 per annum|

####  Summary

We are a team of high performance individuals. Artists. The starting lineup. Always hunting for the next best product, strategy, execution. Whether you’re with us in our offices in Santa Clara and San Francisco, or even remotely, a job at Decentral will be demanding. Yet we reward those that deliver results. Those that can think bottom up, from a first principles standpoint. And we wouldn’t ask for anything else. 

At Decentral, we don’t just build software. We innovate where we are recognized at the top of adjacent industries. Join the team that manifests the standards of excellence, and that does whatever it takes to realize that value. We want your unique experience and strengths to guide us to a better tomorrow. 

Does a resourceful, dynamic and withstanding environment activate your reticular activation system? Do you like to venture into that part of the world where you can’t “Google your answers” to solve your problems anymore? It happens when your abilities cross the threshold from exceptional into elite. If you know what that feels like, you’ll be a great fit for our team!

![image](https://s3-us-west-2.amazonaws.com/fireteam-alpha/https-decentral-solutions-cdn/DSC00762_preview.jpeg)

A couple of requirements so that you’ll be ready to hit the ground running. 

- You are focused obsessively on delivering results
- You possess excellent written and verbal communication skills in English. 
- You are comfortable working with those with different backgrounds and vocation and can speak their language

> Hiring Update: Our firm has transitioned to a work from home model and we're continuing to interview and hire during this time. This position shall begin initially as a remote position. Based on circumstances we will work with you to explore transition to in-office and or hybrid remote work. 

#### Requirements

- Design and build a distributed systems security policy that suites our firm as we scale
- Implement and cover all aspects of securing the software engineering lifecycle
- Make decisions regarding technologies used, which facilities to operate out of, create IT budgets that falls within scope of the firm's overall strategic focus
- In depth knowledge of Linux (Ubuntu/RHEL/CentOS) shell scripting, low level networking, PKI fundamentals


#### Ideal Qualifications

* 4 year degree in Computer Science
* CompTIA A+/Network+/Security+ Certification
* Extensive experience with Network, DB and Filesystem administration
* Professional experience with Program Management and leading a lean and efficient QA and DevOps team 
* Blockchain industry experience including hands-on experience working with Ledger and Trezor wallets
