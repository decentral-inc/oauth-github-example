# Index

## FSC ID Number


![image](./fsc-2022-03-05.jpg)


##


|Category| |Example |
|-|-|-|
|Firearm Type | |Handgun, Rifle, Shotgun, Rifle/Shotgun Combo |
|Make|Smith & Wesson |Remington, Winchester, Glock |
|Model |M&P9SHLD(BK)HIVIZ#11905 | |
|Caliber | 9| |
|Firearm Origin | | |
|Barrel Length | | |
|Date Acquired | |The date you, the person submitting this report, took possession of the firearm |


|Required|Value|Notes |
|-|-|-|
|Firearm Type| |Handgun, Rifle/Shotgun Combo, Rifle, Shotgun|
|Category|Semi-Automatic| |
|Firearm Safety Certificate (FSC) No.| | |
|Firearm Self-Built |No |Y/N |
|Did you obtain a serial number from the DOJ? | |Y/N|
|Frame/Receiver Only?| |Double check|
|Is Firearm in Law Enforcement Custody? |Yes |Y/N |
|Frame/Receiver Only |No | |
|Color |Black | |
|Serial Number |JDM5112 | |
|DROS Number |09310-03519 | |