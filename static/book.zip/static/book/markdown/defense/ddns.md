# Comprehensive guide on setting up Dynamic DNS

#### Assumptions

1. Have multiple routers
2. On development notebook machine
3. Running Mac OS


## How it works

1. Servers validate one controls the domain names associated with that certificate.
2. LetsEncrypt servers validate it using concept called "Challenges"