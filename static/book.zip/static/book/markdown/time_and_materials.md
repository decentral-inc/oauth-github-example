# Time and Materials

Assume cost pre taxes and other deductions

|description|time|cost per hour|total|
|--|--|--|--|
|dev env including dependencies, gas, faucet, dotenv, config management|5 |  |  |
|minting and generation logic of NFT  |10  |  |  |
|integratiion tests with wallets  |10  |  |  |
|authentication with user login and logout  |10  |  |  |
|user is able to change their OAuth2 Provider |12  |  |  |


# Hello 

## World