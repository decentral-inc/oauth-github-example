# Valuation 


### Pre-money Valuation is determined by 

- Market cap `->` 🙅‍♀️ `->` pre-product and shares are illiquid
- Earnings multiplier method `->`  earnings <= EBIDTA

> Know that this number will typically be negotiated upon between yourself and the VC's coming in on your deal



### Documentation Section


```js
let expenses = [
 ["restaurants and dining", 10000],
 ["flights", 7500],
 ["hotels", 16000],
 ["office food water and supplies", 26000],
 ["conference and event sponsorships", 10000],
]; //sums to $69,500

let expenses_total = expenses.map(function (tuple) {
  let [l,r] = tuple;
  return r; 
}).reduce(function (memo,num) {
  return memo += num; 
},0);
```

### Calculation Section

```js

let quantity_sold = 100000;
let price = 170; // USD
let total_revenue = price * quantity_sold; // $17,000,000
let earnings = total_revenue - expenses_total; // $16,930,500
let conservative_valuation = earnings * 5.00; // $84,652,500
let optimistic_valuation = earnings * 12.67; // $214,509,435
```

### Industry Standard

The _Enterprise Value_ (also known as the firm's _valuation_) of a company can be quickly calculated by the formula

`EV = EBIDTA * industry_multiplier` where `industry_multiplier` for Software firms is on average `12.67`

```

   169305500.00
x         12.67 
---------------
$  214509435.00    			=>		   	$  214,509,435.00
```

Pre-money Valuation is determined by

* Market size: aggregate $ spent on the entire industry
* Market share: percent of market that goes 
* Revenue
* Multiple: EBIDTA multiple
* Valuation: Derived from each of the above




Reference: [Fool.com](https://www.fool.com/the-blueprint/pre-money-valuation/)  

## IV. Scenario Section

Let's say you have an investor who is ready to deploy capital. What are all the steps A-Z needed to successfully close out that round 

```json
{
  "round": "1A",
  "amount": 500
}
```

### 2.1 Pull up existing cap table

Pull up the existing cap table and inspect to verify it is up to date 

We can decompose that into either selections

#### 2.1.1

![image](https://user-images.githubusercontent.com/5965718/158074827-1074c455-9f06-4141-87d5-541c6bc51846.png)

[DigitalAssetCapTable](https://docs.google.com/spreadsheets/d/10fU64_ORUzS52nV5BvVRpbfQFbFDfr7XGlMEiocMJD4/edit#gid=0)


#### 2.1.2

![image](https://user-images.githubusercontent.com/5965718/158079320-b57c97eb-b870-4934-9a2a-5ac5130d29fe.png)


[TraditionalCapTable](./cap_table.md#figure-1a)

### 2.2 Comments

* There has to be a new round
* Round justified by a valuation with a marked increase


## 3. Buildup Section

> Prompt: I have $500 ready to deploy into your company

Proper response: We're raising $1,111,111.11 on a valuation of 3.5 million. 

While speaking this: internally your mindset must be able to list out all of the free grants and accelerator funds you're able to receive based on the work of your grant writers. Your mindset should be this is a unique opportunity to be in early on such a great project. 

Investors will want to see live users. Ideally live paying users. 

How did I arrive at this? Read below

We shall pick route `2.1.2`. That means we have to go from the basic seed cap table 

![image](https://user-images.githubusercontent.com/5965718/158084502-b4e106e2-8766-4dc3-9a82-c383f6c92b5b.png)


into... 

![image](https://user-images.githubusercontent.com/5965718/158084479-253709a7-c66c-4a05-ae3f-fcb25c8dd9bf.png)

and then filling in the rest

![image](https://user-images.githubusercontent.com/5965718/158085491-625fd0e0-0b1d-4167-a940-ca543abeee73.png)

until finally we get a 2 view layout


![image](https://user-images.githubusercontent.com/5965718/158084438-241374d4-f426-488b-a255-fa1d0c1f122f.png)

### 3.1 Toy Scenario

Before we jump into that let's analyze this toy scenario

| NAME                  | ISSUANCE DATE | SHARES HELD |   | PURCHASE AMOUNT |   |
|-----------------------|---------------|-------------|---|-----------------|---|
| LING QING MENG        | 8/24/2018     | 200,000     |   | $20.00          |   |
| JESSE DAWSON          | 8/24/2018     | 200,000     |   | $20.00          |   |
| TAMARA FRANKEL        | 8/22/2018     | 200,000     |   | $20.00          |   |
| DILLON SETTLE         | 8/21/18       | 200,000     |   | $20.00          |   |
| EMPLOYEE OPTIONS POOL | 8/23/2018     | 100,000     |   |                 |   |


