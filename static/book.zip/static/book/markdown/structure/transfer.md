# Share Transfer Laws

Any owner of corporate stock may transfer it to some new owner. The only exception is if _there are valid restrictions on transferability, which can be deduced by inspecting the bylaws_

> In general, restrictions on transferability should be noted on the face of the stock certificate

### Right of first refusal

Defined as a situation where shareholders restrict the transferability by reserving the right (but not obligation) to purchase any shares offered for resale by a shareholder


### Private offerings

#### Methodology

How to legally offer securities under the private (Reg D) offering exemption. 

#### Requirements

* Offer must be limited to sophisticated investors 
* If there exists unaccredited investors, issuer shall provide material information to all purchasers. 
  - Material information must include information about itself, its business, about the securities prior to the sale


### Professional Services

#### Methodology

Let's assume you are just starting a startup and want to have the best in class corporate counsel design your terms and conditions for your logistics platform

#### Requirements

* Corporation must be formed
* Falls under umbrella of _Watered Shares_ legal framework
* Shares _must not_ be purchased with promissory notes
* Outside the scope of cash for shares, Shares may be paid for by 
  - Property
  - Services rendered
