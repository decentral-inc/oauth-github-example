# Deal Structure 




### Convertible Note

A Convertible Note is also a Convertible Bond or also known as a Convertible Debt or also known as a Convertible Debenture. [[1]](./index.md#references) [[2]](./index.md#2-scatizzi-cara-february-2009-convertible-bonds-the-aaii-journal-retrieved-8-september-2015)


A convertible note holder can convert the security to a specified number of shares of common stock in the issuing company or cash of equal value. 

When interacting with Securities, reference the page on [transfer](./transfer.md#private-offerings) laws  

#### Only Digital Assets

What would the numbers look like for this offering? 


# References

### 1. Stanley, D. (Nov 2017) [Convertible debt note bond](https://money.stackexchange.com/questions/87023/convertible-debt-note-bond-debentures-which-of-these-are-the-same-or-differen)
### 2. Scatizzi, Cara (February 2009). "[Convertible Bonds](http://www.aaii.com/journal/article/convertible-bonds.touch)". The AAII Journal. Retrieved 8 September 2015.
### 3 Orrick. Board of Approval Option Grant. [Download docx file](./board-approval-of-option-grant.docx)
