# Cap Table 

## Instructions

How to perform duties as controller

#### Step 1

Determie the amount for first raise that can be justified, and can handle enough for all costs that can occur in a business setting

> While doing this exercise we know that the first board of directors is either _named in the articles of incorporation_ or _chosen by the incorporators to serve until the first shareholders' meeting_

#### Step 2

Sum up `1,925,000` shares then divide total pre-money valuation `$3,750,000`

> While doing this exercise, as a follow up to the quoted text in step 1: law states selection and retention of directors are _exclusively a shareholder function_


#### Step 3

In literature the result of step 2 is actually called `Series *` price per share, but basically solve all in the `Total ($)` column for this round. Double check `Total ($)` subtotal reconciles. Ensure not off with rounding. 

> While doing this exercise we know the corporation law that _Shareholders must approve fundamental changes affecting the corporation before the changes can be effected_


#### Step 4

Do a quick chceck on summing up both pre and post. In our case quantity of dollars is `$6,250,000.00` and share count is 3,208,333. The quotient turns out to still be `$ 1.948052` per share. 


#### Step 5 

If doing convertible debt financing, review the terms specific to that

> 

## Figure 1A



| Round    | Number of Shares | Price   | Investor | Percentage | Total ($)      |
|----------|------------------|---------|----------|------------|----------------|
| 1A       | 1,000,000        |  $1.948 | Alice    |            |  $1,948,051.00 |
| 1B       | 500,000          |  $1.948 | Bob      |            |  $1,974,025.50 |
| Series A | 200,000          |  $1.948 | Charlie  |            |  $389,610.20   |
| Series B | 200,000          |  $1.948 | David    |            |  $389,610.20   |
| Series C | 25,000           |  $1.948 | Ellie    |            |   $48,701.28   |



### Explanation

In order to calculate ownership percentage find the sum so answering question how much is the company worth? The pre-money valuation is the guess up in the air. Various models can be used to determine that. 






