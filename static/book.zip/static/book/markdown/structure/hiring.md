# How to hire an employee and issue them options

#### 1. Preq-Reqs

1. Check the status of the cap table - Confirm the size of the employee option pool during the moment of successfully raising outside capital.
2. Inteview confirms the eligibility for recruit to work in the US
3. Have at least $2,500 if you are filing Form I-140 requesting EB-1, EB-2, or EB-3 immigrant visa classification. (If you are filing Form I-129 requesting E-1, E-2, E-3, H-1B, H-3, L (including blanket L-1), O, P, Q, or TN nonimmigrant classification)

#### 2. Main Parts

Assuming Employee is a US Citizen

1. Offer letter is sent out
1. Employee accepts and signs the employee agreement
1. Employee signs either the [Delaware S Corp option agreement document](./option-agreement-s.docx) or [Delaware C Corp options agreement document](./option-agreement-c.docx)


Assuming Employee is NOT a US Citizen. 

1. Categorize as either E1 (Priority Worker or Extraordinary Ability) or E2 (Professionals Holding Advanced Degrees and Persons of Exceptional Ability)
1. Employer sends Job Offer and then fills out [Form I-140] while collecting information such as their name, mailing address, passport and travel document information. The Employer will need to have figures ready for
  * Type of Business
  * Date Established
  * Current Number of US Employees
  * Gross Annual Income
  * Net Annual Income
  * NAICS Code
  * Labor Certification DOL Case Number
  * Labor Certification DOL Filing Date
  * Labor Certification Expiration Date
1. View rest of instructions on [gov reference page](https://www.uscis.gov/i-129-addresses)

#### 3. ESOP

How does a [ESOP](https://www.irs.gov/pub/irs-tege/epchd804.pdf) work? 

![image](https://user-images.githubusercontent.com/5965718/162647717-0969631c-1ba1-4b5d-9836-46abb4944138.png)

* Lets say the company is at the point in its financing where it raised its pre-seed round and is about to offer _Promises_ of Equity. These are typically in the form of _Restricted Stock Units_. 
* The company ratifies a _Stock Bonus Plan_ which will typically be part of the Employee Handbook. It is the firm's reponsibility to notify the participant of how much they own and how much their stock is worth
* Best practices is for the firm to create separate accounts (as opposed to UTXO) for each participant, then the stock is allocated to the participant's account based on the **formula defined in the contract** representing the Employee Stock Ownership Plan

#### 4. Valuation

How valuation is determined for Employer Securities

> Company stock not readily tradeable on an established securities market shall be valued by an independent appraiser meeting requiremetns similar to the requirements of the Regulations prescribed under Code Sction 170(a)(1)


