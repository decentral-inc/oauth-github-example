# Instruction on how BOD Authorizes Securities


## How to Authorize


1. BOD actions must be done prior to the state of "Initial Closing". The Agreements of the note shall constitute valid and legally binding obligations of the company
2. Prior to step 1 above, the authorized capital stock of the Company miust be published (submitted) as a fillable field in the contract. 2 fields must be filled for common stock and preferred stock. 
3. After both above steps done, confirm and publish in contract


#### Definition

**Equity securities**: Shall mean the company's common stock or preferred stock or any securities conferring the right to vote

