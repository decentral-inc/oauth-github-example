# Common Stock

Example of progression in the cap table. Let us adjust the numbers.

> Prompt: When an investor is ready to deploy capital, what are all the steps, A-Z that you'll need to perform so that you are able to secure the correct deal and terms that go along with it

## All Steps A-Z on how to add a new investor 

### Investor A is ready to deploy 50k into your round

As a financial operations lead, what do you do ? 

1. Open these 2 files _Budget: Use the web [app](https://1drv.ms/x/s!ArXiVZwDHyizpDAFsO1O8Rj_BR8P?e=nZ4KRu)_ and _Stockholders: Use the web app [app](https://1drv.ms/x/s!ArXiVZwDHyiznysjr7ELhiwKuNif?e=9fiC6w)_
2. Review the _Pre-money valuation_ figure and ensure you can justify it in a live environment by using the [EBIDTA method](../../structure/ebitda.md#industry-standard)
3. Then locate the [basic convertibel note contract](https://github.com/decentral-foundation/clean-press/blob/product-prerelease/common/raw/convertible_note.md) we sign on our document signing [tool](https://www.pandadoc.com/) and compare it with a [YC SAFE](./Postmoney_Safe_Valuation_Cap_Only_v1.1.docx) contract  
4. Review the [SAFE Financing quick start guide](https://1drv.ms/b/s!ArXiVZwDHyizpEa0AXxupbcZX8Qc) and extrapolate contract logic to Convertible Note depending on context of deal.

## I. Pre-seed

### Fundamental concepts

So we know that our goal is to retain as much ownership as possible for the founders. Yet we want to raise enough money so that 

#### Table View 1A-Y

| Cap table after Pre-seed | Common  | Pre-seed | Seed | Series A | Total   | % Ownership |
|--------------------------|---------|----------|------|----------|---------|-------------|
| LING QING MENG           | 710,000 |          |      |          | 710,000 | 71.00%      |
| JESSE DAWSON             | 50,000  |          |      |          | 50,000  | 5.00%       |
| TAMARA FRANKEL           | 25,000  |          |      |          | 25,000  | 2.50%       |
| DILLON SETTLE            | 15,000  |          |      |          | 15,000  | 1.50%       |
| Employee Option Pool     | 100,000 |          |      |          | 100,000 | 10.00%      |
| Investors per stage      |         | 99,990   |      |          | 99,990  | 10.00%      |
| Total                    | 900,000 |          |      |          | 999,990 | 100.00%     |


## II. Seed

Furthermore: regularly in the course of business you'll be required to recruit candidates such as a CTO. Part of those conversations will involve figures around equity. As part of the recruitment process, you'll have contracts that detail employee compensation plans. These plans come with bonuses, oftentimes which will be a function of the EBITDA delta of the period of which the employee has formally signed contract. 

So the next step is to determine the monthly burn rate for cash in business to be spent on...

* Marketing expenses
* Salary
* Bonuses
* Hosting costs
* 3rd party software subscriptions and licenses
* Support costs such as the budget required for a call center


#### Table View 2A-Y

| Cap table after Pre-seed | Common  | Pre-seed | Seed    | Series A | Total     | % Ownership  |
|--------------------------|---------|----------|---------|----------|-----------|--------------|
| LING QING MENG           | 710,000 |          |         |          | 710,000   | 56.80%       |
| JESSE DAWSON             | 50,000  |          |         |          | 50,000    | 4.00%        |
| TAMARA FRANKEL           | 25,000  |          |         |          | 25,000    | 2.00%        |
| DILLON SETTLE            | 15,000  |          |         |          | 15,000    | 1.20%        |
| Employee Option Pool     | 100,000 |          |         |          | 100,000   | 8.00%        |
| Investors per stage      |         | 99,990   | 249,998 |          | 349,988   | 28.00%       |
| Total                    | 900,000 |          |         |          | 1,249,988 | 100.00%      |


## III. Series A

#### Table View 3A-Y

| Cap table after Pre-seed | Common  | Pre-seed | Seed    | Series A | Total     | % Ownership  |
|--------------------------|---------|----------|---------|----------|-----------|--------------|
| LING QING MENG           | 710,000 |          |         |          | 710,000   | 43.55%       |
| JESSE DAWSON             | 50,000  |          |         |          | 50,000    | 3.07%        |
| TAMARA FRANKEL           | 25,000  |          |         |          | 25,000    | 1.53%        |
| DILLON SETTLE            | 15,000  |          |         |          | 15,000    | 0.92%        |
| Employee Option Pool     | 100,000 |          |         |          | 100,000   | 6.13%        |
| Investors per stage      |         | 99,990   | 249,998 | 380,431  | 730,419   | 44.80%       |
| Total                    | 900,000 |          |         |          | 1,630,419 | 100.00%      |

# FAQ

#### Q: At what point will Employee Option Shares convert into real shares so that those employees are able to execute their voting power? 

A: _todo_

