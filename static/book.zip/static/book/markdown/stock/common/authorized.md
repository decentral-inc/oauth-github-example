# Authorized Shares

For Shares to be authorized, they must have voting approval.

## Table View 1A-X

| Pre-Seed Round of Funding    |        |                                              |
|------------------------------|--------|----------------------------------------------|
| Pre-Money Valuation          | Step 5 | Often negotiated between founder and VC      |
| Amount Raised                | Step 2 | Budget req to justify valuation increase     |
| Post-Money Valuation         | Step 6 | Sum above two rows                           |
| % Ownership of new Investors | Step 7 | Divide amount raised by post money valuation |
| Initial Outstanding Shares   | Step 1 | Num shares don't change                      |
| Post Investment Shares       | Step 3 | Figure this after budget                     |
| New shares constructed       | Step 4 | Take the difference                          | 

While performing the exercise you'll have to fill in the values in the placeholder cell for each Step

<details>
  <summary><strong>⚙️ Round 1A-X View 1A-X</strong></summary>
  
| Pre-Seed Round of Funding    |             |        |                                       |
|------------------------------|-------------|--------|---------------------------------------|
| Pre-Money Valuation          | $2,000,000  | Step 5 | In order to do step 3                 |
| Amount Raised                | $222,200    | Step 2 | We need to first know amount          |
| Post-Money Valuation         | $2,222,200  | Step 6 | of capital being deployed by          |
| % Ownership of new Investors | 10.00%      | Step 7 | Investor A and B and at what          |
| Initial Outstanding Shares   | 900,000     | Step 1 | pre-money valuation. Then perform     |
| New shares constructed       | 99,990      | Step 3 | the division and tally up the shares  |
| Post Investment Shares       | 999,990     | Step 4 | to arrive at new shares issued count  |

</details>
<hr/> 




## Table View 1A-Z

How to solve the remaining sections and fill out a complete cap table.

1. Sum up all the `issued shares` that have been given to the initial founding members. 
2. Define the corporate `budget` in terms of annual requirements
3. Recall the `pre-money valuation` number. For this exercise lets set the value to be `$2,000,000.00`
4. Add `budget` to `pre-money valuation` to get `post-money valuation`
5. Calculate `price per share` =  `pre-money valuation` / `issued shares`
6. Now obtain the `proposed amounts` of capital from each investor that would like to deploy capital into your firm. 
7. Create a table (or matrix) where each row `allocation` = `proposed amounts` / `price per share`
8. Sum up all `allocation` amounts and this is the amount of `authorized shares` you will have to gain permission from your Board of Directors to authorize



|Order | Calculation |Note |
|-|-|-|
|Step 5 |`2e6` / `9e5` = `$2.22 per share` |  Repeating 2 after decimal point|
|Step 6 | `1e5` / `2.22` = `45k` | Subtotal |
|Step 7 | `1.22e5` / `2.22` = `54.99k`  | Subtotal |
|Step 8 | `45k`  + `54.99k` = `99,990`| Number of shares |


<details>
  <summary><strong>⚙️ Round 1A-Z View 1A-Z</strong></summary>
  
| Shareholder Pre-Seed  | USD Invested | Common Shares  | Pre-seed Shares | Price per share | Percentage  |
|-----------------------|--------------|----------------|-----------------|-----------------|-------------|
| LING QING MENG        |              | 710,000        |                 |                 | 71.00%      |
| JESSE DAWSON          |              | 50,000         |                 |                 | 5.00%       |
| DILLON SETTLE         |              | 15,000         |                 |                 | 1.50%       |
| TAMARA FRANKEL        |              | 25,000         |                 |                 | 2.50%       |
| EMPLOYEE OPTIONS POOL |              | 100,000        |                 |                 | 10.00%      |
| INVESTOR A            | $100,000     |                | 45,000          | $2.2222         | 4.50%       |
| INVESTOR B            | $122,000     |                | 54,990          | $2.2222         | 5.50%       |
| TOTAL                 | $222,000     | 900,000        | 99,990          |                 | 100.00%     |

</details>

<hr/> 

Investor C now wants to invest `$500.00` in the round before it closes.   
Investor D now wants to invest `$9,500.00` in the round before it closes.


<hr/> 

## Table View 1B-Z

| Pre-Seed Round of Funding    |            |        |
| ---------------------------- | ---------- | ------ |
| Initial Outstanding Shares   | 900,000    | Step 1 |
| Amount Raised                | $232,000   | Step 2 |
| New shares constructed       | 104,925    | Step 3 |
| Post Investment Shares       | 1,004,925  | Step 4 |
| Pre-Money Valuation          | $1,990,000 | Step 5 |
| Post-Money Valuation         | $2,222,000 | Step 6 |
| % Ownership of new Investors | 10.44%     | Step 7 |  

<details>
  <summary><strong>⚙️ Round 1B-Z</strong></summary>  

| Shareholder Pre-Seed  | USD Invested | Common Shares  | Pre-seed Shares | Price per share | Percentage |
|-----------------------|--------------|----------------|-----------------|-----------------|------------|
| LING QING MENG        |              | 710,000        |                 |                 | 70.65%     |
| JESSE DAWSON          |              | 50,000         |                 |                 | 4.98%      |
| DILLON SETTLE         |              | 15,000         |                 |                 | 1.49%      |
| TAMARA FRANKEL        |              | 25,000         |                 |                 | 2.49%      |
| EMPLOYEE OPTIONS POOL |              | 100,000        |                 |                 | 9.95%      |
| INVESTOR A            | $100,000     |                | 45,226          | $2.21           | 4.50%      |
| INVESTOR B            | $122,000     |                | 55,176          | $2.21           | 5.49%      |
| INVESTOR C            | $500         |                | 226             | $2.21           | 0.02%      |
| INVESTOR D            | $9,500       |                | 4,296           | $2.21           | 0.43%      |
| TOTAL                 | $232,000     | 900,000        | 104,925         |                 | 99.55%     |

</details>
<hr/> 

## Bonus

As a fun exercise these would be the values if we incremented them further by an order of magnitude each time

### Table View 1C-Z

| Pre-Seed Round of Funding    |            |        |
| ---------------------------- | ---------- | ------ |
| Initial Outstanding Shares   | 900,000    | Step 1 |
| Amount Raised                | $317,500   | Step 2 |
| New shares constructed       | 143,593    | Step 3 |
| Post Investment Shares       | 1,043,593  | Step 4 |
| Pre-Money Valuation          | $1,990,000 | Step 5 |
| Post-Money Valuation         | $2,307,500 | Step 6 |
| % Ownership of new Investors | 13.76%     | Step 7 |

<details>
  <summary><strong>⚙️ Round 1C-Z</strong></summary>

  
| Shareholder Pre-Seed  | USD Invested | Common Shares  | Pre-seed Shares | Price per share | Percentage |
|-----------------------|--------------|----------------|-----------------|-----------------|------------|
| LING QING MENG        |              | 710,000        |                 |                 | 68.03%     |
| JESSE DAWSON          |              | 50,000         |                 |                 | 4.79%      |
| DILLON SETTLE         |              | 15,000         |                 |                 | 1.44%      |
| TAMARA FRANKEL        |              | 25,000         |                 |                 | 2.40%      |
| EMPLOYEE OPTIONS POOL |              | 100,000        |                 |                 | 9.58%      |
| INVESTOR A            | $100,000     |                | 45,226          | $2.21           | 4.33%      |
| INVESTOR B            | $122,000     |                | 55,176          | $2.21           | 5.29%      |
| INVESTOR C            | $500         |                | 226             | $2.21           | 0.02%      |
| INVESTOR D            | $95,000      |                | 42,965          | $2.21           | 4.12%      |
| TOTAL                 | $317,500     | 900,000        | 143,593         |                 | 95.86%     |

</details>

### Table View 1D-Z

| Pre-Seed Round of Funding    |            |        |
| ---------------------------- | ---------- | ------ |
| Initial Outstanding Shares   | 900,000    | Step 1 |
| Amount Raised                | $1,172,500 | Step 2 |
| New shares constructed       | 530,276    | Step 3 |
| Post Investment Shares       | 1,430,276  | Step 4 |
| Pre-Money Valuation          | $1,990,000 | Step 5 |
| Post-Money Valuation         | $3,162,500 | Step 6 |
| % Ownership of new Investors | 37.08%     | Step 7 |

<details>
  <summary><strong>⚙️ Round 1D-Z</strong></summary>
  
| Shareholder Pre-Seed  | USD Invested | Common Shares  | Pre-seed Shares | Price per share | Percentage |
|-----------------------|--------------|----------------|-----------------|-----------------|------------|
| LING QING MENG        |              | 710,000        |                 |                 | 49.64%     |
| JESSE DAWSON          |              | 50,000         |                 |                 | 3.50%      |
| DILLON SETTLE         |              | 15,000         |                 |                 | 1.05%      |
| TAMARA FRANKEL        |              | 25,000         |                 |                 | 1.75%      |
| EMPLOYEE OPTIONS POOL |              | 100,000        |                 |                 | 6.99%      |
| INVESTOR A            | $100,000     |                | 45,226          | $2.21           | 3.16%      |
| INVESTOR B            | $122,000     |                | 55,176          | $2.21           | 3.86%      |
| INVESTOR C            | $500         |                | 226             | $2.21           | 0.02%      |
| INVESTOR D            | $950,000     |                | 429,648         | $2.21           | 30.04%     |
| TOTAL                 | $1,172,500   | 900,000        | 530,276         |                 | 69.94%     |

</details>
<hr/> 

