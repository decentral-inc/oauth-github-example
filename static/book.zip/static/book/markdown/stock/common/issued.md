# Issued Shares


## FAQ

#### Q: Where is capital structure of the corporation defined? 

A: In the Articles of Incorporation
 