# Cumulative Preferred Stock

* A type of preferred stock for dividend structuring
* Owners of cumulative preferred stock is further ahead in the priority queue, ahead of common stock holders
