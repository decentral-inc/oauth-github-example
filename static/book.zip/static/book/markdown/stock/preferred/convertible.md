# Convetible Preferred Stock

* Give shareholders the option to convert the shares into a specified amount of common shares
* Give holders options to convert shares into the stock of another corporate entity
