# Preferred Stock

Most important takeaway: Preferred stock shareholders typically **do not have voting rights.**

Composed of

1. Cumulative Preferred
2. Participating Preferred
3. Convertible Preferred
4. Redeemable Preferred (aka Callable Preferred)
